package hello.lucene;

import org.junit.Test;

public class SearchTest {

	@Test
	public void testSearch() {
		Search search = new Search();
		search.search();
	}

}
