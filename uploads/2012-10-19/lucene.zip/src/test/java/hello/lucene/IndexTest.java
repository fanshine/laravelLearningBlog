package hello.lucene;

import java.io.IOException;

import org.junit.Test;

public class IndexTest {

	@Test
	public void testIndex() {
		Index index = new Index();
		try {
			index.index();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
